// Brian Foster Coding 1 Fall 2026
// headers

#include "robot.hpp"
#include <iostream>
#include <string>
using namespace std;

int main() {
    robot artoo;        // "new robot"
    artoo.status();     // my name is...

    return 0;
}